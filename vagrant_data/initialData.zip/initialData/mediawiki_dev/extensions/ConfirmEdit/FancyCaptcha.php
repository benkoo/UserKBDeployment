<?php
require_once __DIR__ . "/FancyCaptcha/FancyCaptcha.php";
